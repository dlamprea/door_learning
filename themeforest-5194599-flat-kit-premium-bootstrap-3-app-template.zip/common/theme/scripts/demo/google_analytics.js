/* ==========================================================
 * FLAT KIT v2.0.0
 * google_analytics.js
 * 
 * http://www.mosaicpro.biz
 * Copyright MosaicPro
 *
 * Built exclusively for sale @Envato Marketplaces
 * ========================================================== */ 

$(function()
{
	// initialize charts
	if (typeof charts != 'undefined') 
		charts.initGoogleAnalytics();
});