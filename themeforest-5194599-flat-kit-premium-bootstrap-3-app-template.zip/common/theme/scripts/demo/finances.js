/* ==========================================================
 * FLAT KIT v2.0.0
 * finances.js
 * 
 * http://www.mosaicpro.biz
 * Copyright MosaicPro
 *
 * Built exclusively for sale @Envato Marketplaces
 * ========================================================== */ 

$(function()
{
	// initialize charts
	if (typeof charts != 'undefined') 
		charts.initFinances();
});