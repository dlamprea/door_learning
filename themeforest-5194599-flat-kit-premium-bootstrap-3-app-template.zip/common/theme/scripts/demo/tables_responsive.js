/* ==========================================================
 * FLAT KIT v2.0.0
 * tables_responsive.js
 * 
 * http://www.mosaicpro.biz
 * Copyright MosaicPro
 *
 * Built exclusively for sale @Envato Marketplaces
 * ========================================================== */ 

$(function()
{
	/* FooTable */
	if ($('.footable').length)
		$('.footable').footable();
});